package com.example.mendezsanchezluisexamenfinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.mendezsanchezluisexamenfinal.database.AppDatabase;
import com.example.mendezsanchezluisexamenfinal.database.TareaDao;
import com.example.mendezsanchezluisexamenfinal.modelo.Tarea;

public class TareaActivity extends AppCompatActivity {

    private static final String TAG = "CreateTarea";

    private EditText etNombres, etDescripcion, etDuracion;
    private Button btnAgregar;
    private Tarea tarea;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarea);
        etNombres=findViewById(R.id.etNombre);
        etDescripcion=findViewById(R.id.etDescripcion);
        etDuracion=findViewById(R.id.etDuracion);

        final AppDatabase db= Room.databaseBuilder(getApplicationContext(), AppDatabase.class, "production")
                .allowMainThreadQueries()
                .build();
        btnAgregar=findViewById(R.id.btnAgregar);
        btnAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tarea= new Tarea(etNombres.getText().toString(),etDescripcion.getText().toString(),etDuracion.getText().toString());
                db.tareaDao().insertAll(tarea);
                startActivity(new Intent(TareaActivity.this, MainActivity.class));
            }
        });

    }
}

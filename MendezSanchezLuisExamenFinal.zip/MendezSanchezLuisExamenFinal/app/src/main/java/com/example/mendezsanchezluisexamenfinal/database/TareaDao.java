package com.example.mendezsanchezluisexamenfinal.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.mendezsanchezluisexamenfinal.modelo.Tarea;

import java.util.List;

@Dao
public interface TareaDao {

    @Query("SELECT * FROM Tarea")
    List<Tarea> getAllTareas();

    @Insert
    void insertAll(Tarea... tareas);

    @Update
    public int actualizar(Tarea tarea);

    @Delete
    public int eliminar(Tarea tarea);
}

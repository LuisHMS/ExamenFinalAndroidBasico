package com.example.mendezsanchezluisexamenfinal;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mendezsanchezluisexamenfinal.R;
import com.example.mendezsanchezluisexamenfinal.TareaActivity;
import com.example.mendezsanchezluisexamenfinal.adapter.TareaAdapter;
import com.example.mendezsanchezluisexamenfinal.database.AppDatabase;
import com.example.mendezsanchezluisexamenfinal.database.TareaDao;
import com.example.mendezsanchezluisexamenfinal.modelo.Tarea;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity
        {

    private RecyclerView rvTarea;
    private FloatingActionButton fabAgregar;
    private RecyclerView.Adapter adapter;
    ArrayList<Tarea> tareas;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tareas = new ArrayList<>();

        rvTarea=findViewById(R.id.rvTarea);

        AppDatabase db= Room.databaseBuilder(getApplicationContext(), AppDatabase.class,"production")
                .allowMainThreadQueries()
                .build();
        List<Tarea> tareas= db.tareaDao().getAllTareas();

        rvTarea.setLayoutManager(new LinearLayoutManager(this));
        adapter=new TareaAdapter(tareas);
        rvTarea.setAdapter(adapter);

        fabAgregar = findViewById(R.id.fabAgregar);
        fabAgregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,TareaActivity.class  ));
            }
        });


    }


}

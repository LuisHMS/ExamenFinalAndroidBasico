package com.example.mendezsanchezluisexamenfinal.adapter;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mendezsanchezluisexamenfinal.R;
import com.example.mendezsanchezluisexamenfinal.modelo.Tarea;

import java.util.ArrayList;
import java.util.List;

public class TareaAdapter extends RecyclerView.Adapter<TareaAdapter .ViewHolder>{

    List<Tarea> tareas;

    public TareaAdapter(List<Tarea> tareas) {
        this.tareas = tareas;
    }





    @NonNull
    @Override
    public TareaAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {

        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_lista, viewGroup, false);

        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        viewHolder.tvNombre.setText(tareas.get(i).getNombre());
        viewHolder.tvDescripcion.setText(tareas.get(i).getDescripcion());
        viewHolder.tvDuracion.setText(tareas.get(i).getDuracion());

    }

    @Override
    public int getItemCount() {
        return tareas.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView tvNombre, tvDescripcion, tvDuracion;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre=itemView.findViewById(R.id.tvNombre);
            tvDescripcion=itemView.findViewById(R.id.tvDescripcion);
            tvDuracion=itemView.findViewById(R.id.tvDuracion);
        }

        public void bind(final Tarea contacto, final OnItemClickListener listener){
            tvNombre.setText(contacto.getNombre());
            tvDescripcion.setText(contacto.getDescripcion());
            tvDuracion.setText(contacto.getDuracion());

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onItemClick(contacto, getAdapterPosition());
                    Log.d("ContactoAdapter", contacto.getNombre());
                    //Intent
                }
            });
        }

    }
    public interface OnItemClickListener{
        void onItemClick(Tarea tarea, int i);
    }

}
